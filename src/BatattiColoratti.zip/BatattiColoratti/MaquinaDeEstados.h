#ifndef _MAQUINAESTADOS_H_
#define _MAQUINAESTADOS_H_

int Localiza();
int Gira180();
int SegueLinha();
int OlhaCor();
int GiraBase();
int RetornaBase();
int RecuaBase();
int Recua();
int Gira60();
int GiraMenos60();
int AndaReto();
int MaquinaDeEstados(int estadoAtual);

#endif

#include "Tarefas.h"
#include "Movimentacao.h"
#include "Configuracao.h"
#include "SensorDeLuz.h"
#include "MaquinaDeEstados.h"

int SegueLinha_flag = 0 ;
/*
int Inicio(){

	if(start == 1){

		return LOCALIZA;
	}else 

	return INICIO;
}
*/
int Localiza(){

	Tarefas::AlinhaComLampada();

	return GIRA180;
}

int Gira180(){

	gira_sentido_antihorario(12);

	return SEGUELINHA;
}


int SegueLinha(){

	if(DetectaObjeto()){
		para();
    SegueLinha_flag = 0;

		return OLHACOR;
		// zerar variaveis globais de SegueLinha caso saia do estado SegueLinha!! 
	}else {

		SegueLinha_flag = Tarefas::SegueLinha(SegueLinha_flag);
	}

	return SEGUELINHA;
}

// IMPLEMENTAR CORES 
int OlhaCor(){

	char cor = DetectaCor();
	if(cor == black || cor == green){

		return RECUA; 
	}else {

		return GIRABASE;
	}
}


int GiraBase(){

	Tarefas::AlinhaComLampada();

	return RETORNABASE;
}


int RetornaBase(){

	anda(30);

	return RECUABASE;
}

int RecuaBase(){

	anda_re(10);

	return GIRA180;
}



int Recua(){

	anda_re(10);

	return GIRA60;
}

int Gira60(){

	gira_sentido_horario(4);

	return ANDARETO;
}

int GiraMenos60(){

	gira_sentido_antihorario(4);

	return SEGUELINHA;
}


int AndaReto(){


	anda(4);

	return GIRAMENOS60;
}

int MaquinaDeEstados(int estadoAtual){

  int proximoEstado;

	switch(estadoAtual) {

	//	case INICIO:
		//	proximoEstado = Inicio();
		//	break;
		case LOCALIZA:
			proximoEstado = Localiza();
			break; 
		case GIRA180:
			proximoEstado = Gira180();
			break;
		case SEGUELINHA:
			proximoEstado = SegueLinha();
			break;
		case GIRABASE:
			proximoEstado = GiraBase();
			break; 
		case RETORNABASE:
			proximoEstado = RetornaBase();
			break;
		case RECUABASE:
			proximoEstado = RecuaBase();
			break;
		case RECUA:
			proximoEstado = Recua();
			break; 
		case GIRA60:
			proximoEstado = Gira60();
			break;
		case ANDARETO:
			proximoEstado = AndaReto();
			break; 
		case GIRAMENOS60:
			proximoEstado = GiraMenos60();
			break;				 


	}


return proximoEstado;

}

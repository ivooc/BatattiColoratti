#ifndef __SEGUIDOR_DE_LINHA__
#define __SEGUIDOR_DE_LINHA__

#include "Configuracao.h"

namespace SeguidorDeLinha{

    int Seguir (int esquerda, int direita, int flag);
    
} 

#endif
